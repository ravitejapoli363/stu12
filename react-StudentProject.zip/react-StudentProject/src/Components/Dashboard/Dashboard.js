import { useContext } from "react";
import { Link, Route } from "react-router-dom";
import AddStudent from "../AddStudent/AddStudent";

import ContextProvider from "../Store/ContextProvider";
import ViewStudent from "../ViewStudent/ViewStudent";
import "./Dashboard.css";

const Dashboard = () => {
  return (
    <div className="Dashboard container  mt-3">
      <div className="border rounded bg-warning">
        <div className="row options">
          <div className="col-4 link d-flex align-items-center">
            <Link to="/addStudents">Add Students</Link>
          </div>
          <div className="col-4 link d-flex align-items-center justify-content-center">
            <Link to="/viewStudents">View Students</Link>
          </div>
          <div className="col-4 link d-flex align-items-center justify-content-end">
            <Link to="/editStudents">Edit Students</Link>
          </div>
        </div>
      </div>
      <div className="mt-3">
        <ContextProvider>
          <Route path="/addStudents">
            <AddStudent></AddStudent>
          </Route>
          <Route path="/viewStudents">
            <ViewStudent></ViewStudent>
          </Route>
          <Route path="/editStudents">
            <AddStudent></AddStudent>
          </Route>
        </ContextProvider>
      </div>
    </div>
  );
};

export default Dashboard;
