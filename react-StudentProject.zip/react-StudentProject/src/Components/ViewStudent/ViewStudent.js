import { useContext } from "react";
import studentContext from "../Store/Context";

const ViewStudent = () => {
  const ctx = useContext(studentContext);
  return (
    <div>
      {console.log(ctx)}
      {ctx.students.map((student) => {
        return <h1>{student.name}</h1>;
      })}
    </div>
  );
};

export default ViewStudent;
