import React from "react";
const studentContext = React.createContext({
  students: [],
  addStudent: (student) => {},
});

export default studentContext;
