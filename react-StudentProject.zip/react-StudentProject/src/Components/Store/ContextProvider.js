import { React, useReducer } from "react";
import studentContext from "./Context";

const studentReducer = (state, action) => {
  if (action.type === "ADD") {
    const updatedState = [...state.students, action.value];
    console.log(updatedState);
    return {
      students: updatedState,
    };
  }
};

const ContextProvider = (props) => {
  const [studentDispatch, dispatchFun] = useReducer(studentReducer, {
    students: [],
  });
  const addStudent = (student) => {
    dispatchFun({ type: "ADD", value: student });
  };
  const context = {
    students: studentDispatch.students,
    addStudent: addStudent,
  };
  return (
    <studentContext.Provider value={context}>
      {props.children}
    </studentContext.Provider>
  );
};

export default ContextProvider;
